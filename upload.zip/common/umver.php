<?php

define('UniMatrix', 'https://www.mlmscript.net');

// base version
$umbasever = '3.3.2';
$umhitrels = 28;
$umisverin = 1;
$umisverup = 1;
$umverttel = '';
$umisremup = 0;
